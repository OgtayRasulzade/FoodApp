//
//  FoodResponse.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 29.12.22.
//

import Foundation

struct FoodResponse: Codable{
    var foods:[Food]?
}
