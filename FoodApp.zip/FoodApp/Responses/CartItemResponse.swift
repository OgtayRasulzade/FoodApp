//
//  CartItemResponse.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 29.12.22.
//

import Foundation


struct CartItemResponse: Codable{
    var foods_cart:[Food]?
}
