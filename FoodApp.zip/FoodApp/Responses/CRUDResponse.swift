//
//  CRUDResponse.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 29.12.22.
//

import Foundation

class CRUDResponse : Codable {
    var success: Int?
    var message: String?
}
