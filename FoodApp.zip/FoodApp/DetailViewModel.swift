//
//  DetailViewModel.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 29.12.22.
//

import Foundation
import UIKit
import RxSwift
import Kingfisher
import Alamofire

class DetailViewModel {
    
}
