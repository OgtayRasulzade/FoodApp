//
//  DetailScreenViewController.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 23.12.22.
//

import UIKit

class DetailScreen: UIViewController {

    var viewModel = DetailViewModel()
    
    @IBOutlet weak var lblIntroductory: UILabel!
    
    @IBOutlet weak var lblItemPrice: UILabel!
    @IBOutlet weak var lblItemCategory: UILabel!
    @IBOutlet weak var lblItemName: UILabel!
    @IBOutlet weak var lblItemCount: UILabel!
    @IBOutlet weak var imgItem: UIImageView!
    
    var food:Food?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let food = food{
            lblItemPrice.text = "\(food.price ?? 0) AZN"
            lblItemName.text = food.name
//            lblItemCount = "\(food.orderAmount ?? 0)"
//            lblItemCategory = food.category
            
//            imgItem.kf.setImage(with: food.imageURL)
        }

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnMinus(_ sender: Any) {
    }
    
   
    @IBAction func btnPlus(_ sender: Any) {
    }
    
    
    @IBAction func btnAddToCart(_ sender: Any) {
    }
    
    
    
}


