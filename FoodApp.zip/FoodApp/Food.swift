//
//  Foods.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 23.12.22.
//

import Foundation

struct Food: Codable{
    internal init(id: Int? = nil, cartid: Int? = nil, username: String? = nil, orderamount: Int? = nil, name: String? = nil, image: String? = nil, price: Int? = nil, category: String? = nil) {
        self.id = id
        self.cartid = cartid
        self.username = username
        self.orderamount = orderamount
        self.name = name
        self.image = image
        self.price = price
        self.category = category
    }
    
   
    
    
    var id: Int?
    var cartid: Int?
    var username: String?
    var orderamount: Int?
    var name: String?
    var image:String?
    var price:Int?
    var category:String?
    
}
