//
//  FoodsCell.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 24.12.22.
//

import UIKit
import Kingfisher

class FoodsCell: UITableViewCell {

    
    @IBOutlet weak var lblItemPrice: UILabel!
    @IBOutlet weak var lblItemName: UILabel!
    @IBOutlet weak var background: UIView!
    @IBOutlet weak var viewImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var item: Food?
    func configure() {
        lblItemName.text = item?.name
        lblItemPrice.text = String(item?.price ?? 0)
    }

    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    
    
    @IBAction func btnAddToCart(_ sender: Any) {
      
        

    }
    
    func showImage(name:String){
        if let url = URL(string: "http://kasimadalan.pe.hu/foods/images/\(name)"){
            DispatchQueue.main.async {
                self.viewImage.kf.setImage(with: url)
            }
        }
        
    }
    
    
    
    
}
