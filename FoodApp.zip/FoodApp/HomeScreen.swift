//
//  ViewController.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 23.12.22.
//

import UIKit
import RxSwift
import Alamofire
import Kingfisher

class HomeScreen: UIViewController, UITableViewDelegate, UITableViewDataSource {
 
    

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var tblViewMenu: UITableView!
    
  var viewModel = HomeViewModel()

    @IBOutlet weak var lblMenuInfo: UILabel!
    override func viewDidLoad() {
        viewModel.getList{
            self.tblViewMenu.reloadData()
        }
        
        super.viewDidLoad()
        
//        tblViewMenu.register(FoodsCell.self, forCellReuseIdentifier: "FoodsCell")
        
    
        tblViewMenu.delegate = self
        tblViewMenu.dataSource = self
        
        
        
        
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tblViewMenu.dequeueReusableCell(withIdentifier: "FoodsCell" , for: indexPath) as? FoodsCell{
            cell.item = viewModel.list[indexPath.row]
            cell.configure()
            return cell
            
        }
        return UITableViewCell()
    }
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if  let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailScreen") as? DetailScreen {
            navigationController?.present(vc, animated: true)
        }
    }
    
}

