//
//  HomeViewModel.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 27.12.22.
//

import Foundation
import RxSwift
import Alamofire
import Kingfisher


class HomeViewModel{
    var list: [Food] = [
        .init(id: 2, cartid: 1, username: "Oktay", orderamount: 5, name: "Lahmacun", image: "", price: 45, category: "Fast food")
    ]
    
    var service = NetworkService()
    
    func getList (completion: @escaping (() -> Void)) {
        service.getItemList { response in
            self.list = response?.foods ?? []
            print(self.list)
            completion()
            
        }
        
        
        
    }
}
