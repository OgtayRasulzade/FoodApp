//
//  Network.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 28.12.22.
//

import Foundation
import Alamofire
import RxSwift

enum Endpoint: String{
    case getList = "http://kasimadalan.pe.hu/foods/getAllFoods.php"
    case getCartItems = "http://kasimadalan.pe.hu/foods/getFoodsCart.php"
    case addToCart = "http://kasimadalan.pe.hu/foods/insertFood.php"
    case deleteFromCart = "http://kasimadalan.pe.hu/foods/deleteFood.php"
}

class NetworkService{
    static let username = "Oktay Rasulzade"
    static let baseimageURL = "http://kasimadalan.pe.hu/foods/images/"
    
    
    func getItemList(params: Parameters = [:], completion: @escaping ((FoodResponse?) -> Void)) {
        var newParam = params
        newParam["userName"] = NetworkService.username
        AF.request(Endpoint.getList.rawValue, method: .get, parameters: newParam).response {
            response in
            if let data = response.data {
                do{
                    print(data)
                    let result = try JSONDecoder().decode(FoodResponse.self, from: data)
                    completion(result)
                }catch{
                    completion(nil)
                    print(error.localizedDescription)
                }
            }
            
        }
    }
    
    
    
    func requestAddItem(params: Parameters, completion: @escaping ((CRUDResponse?) -> Void)) {
        var newParam = params
        newParam["userName"] = NetworkService.username
        AF.request(Endpoint.addToCart.rawValue, method: .post, parameters: newParam).response {
            response in
            if let data = response.data {
                do{
                    print(data)
                    let result = try JSONDecoder().decode(CRUDResponse.self, from: data)
                    completion(result)
                }catch{
                    completion(nil)
                    print(error.localizedDescription)
                }
            }
            
        }
    }
    
    
    func requestDeleteItem(params: Parameters, completion: @escaping ((CRUDResponse?) -> Void)) {
        var newParam = params
        newParam["userName"] = NetworkService.username
        AF.request(Endpoint.deleteFromCart.rawValue, method: .post, parameters: newParam).response {
            response in
            if let data = response.data {
                do{
                    print(data)
                    let result = try JSONDecoder().decode(CRUDResponse.self, from: data)
                    completion(result)
                }catch{
                    completion(nil)
                    print(error.localizedDescription)
                }
            }
            
        }
    }
    
    
    func requestAllCartItems(completion: @escaping ((CartItemResponse?) -> Void)) {
        let param = ["userName": NetworkService.username]
        AF.request(Endpoint.getCartItems.rawValue, method: .post, parameters: param).response {
            response in
            print(response)
            if let data = response.data {
                do{
                    let result = try JSONDecoder().decode(CartItemResponse.self, from: data)
                    print(result)
                    completion(result)
                }catch{
                    completion(nil)
                    print(error.localizedDescription)
                }
            }
            
        }
    }
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    

