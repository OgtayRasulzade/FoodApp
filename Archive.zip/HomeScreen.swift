//
//  ViewController.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 23.12.22.
//

import UIKit
import RxSwift
import Alamofire
import Kingfisher

class HomeScreen: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    
    

    @IBOutlet weak var lblMenuInfo: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var foodsList = [Foods]()
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    

}

