//
//  FoodsCell.swift
//  FoodApp
//
//  Created by Oktay Resulzade on 24.12.22.
//

import UIKit
import Kingfisher

class FoodsCell: UITableViewCell {

    
    @IBOutlet weak var background: UIView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var viewImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    
    
    @IBAction func btnAddToCart(_ sender: Any) {
    }
    
    func showImage(name:String){
        if let url = URL(string: "http://kasimadalan.pe.hu/foods/images/\(name)"){
            DispatchQueue.main.async {
                self.viewImage.kf.setImage(with: url)
            }
        }
        
    }
    
    
    
    
}
